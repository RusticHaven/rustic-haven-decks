# Rustic Haven Decks Website

This repository contains the website for Rustic Haven Decks, a professional deck construction and repair company.

## Features:
- Home Page with company introduction
- Services Page detailing deck repairs and replacements
- Contact Form for quote requests
- Customer Reviews Section
- FAQ Section
- Deck Maintenance Tips

## How to Deploy:
1. Clone this repository to your local machine.
2. Use Vercel or Netlify to deploy the site.
3. Customize as needed.

